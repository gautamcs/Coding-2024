package com.gautam.mobileaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
